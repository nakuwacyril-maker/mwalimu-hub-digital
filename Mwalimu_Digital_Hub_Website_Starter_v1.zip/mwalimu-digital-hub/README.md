# Mwalimu Digital Hub

A responsive React + Vite starter app for a teacher workspace: CBC lesson planning, timetable slots, class nominal roll and attendance, and teacher resources.

## Current functionality

- Dashboard overview and quick navigation.
- Create, search, view and delete lesson plans.
- Add and remove timetable slots for Monday–Friday; export timetable as CSV.
- Add learners, filter by grade, mark Present/Absent/Late, and export a class register as CSV.
- Add and remove teacher resources.
- Public-facing free-download library with Grade 2 Creative Activities lesson notes in PDF and editable Word formats.
- Data is persisted in the browser using `localStorage` and can be exported as a JSON backup.
- Responsive layout for desktop and mobile.

## Important limitations

This is a working **front-end starter/MVP**, not yet a multi-user production system. Browser-local data stays in the current browser/device and is not automatically synced between devices. There is no login, shared database, server-side validation, or secure cloud storage yet. Do not put sensitive real learner information into a public demo. Those capabilities should be added before real school-wide use.

## Run locally

Install Node.js (LTS), then in this folder run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

To test a production build:

```bash
npm run build
npm run preview
```

## Deploy on Cloudflare Pages using GitHub

1. Create a GitHub repository named `mwalimu-digital-hub`.
2. Upload the contents of this project folder to the **root** of the repository. The root should contain `package.json`, `index.html`, `README.md`, and `src/`.
3. In Cloudflare, open **Workers & Pages** (or **Pages**) and choose **Create application → Pages → Connect to Git** (wording may vary).
4. Select the repository.
5. Use these build settings:
   - Framework preset: **Vite**
   - Build command: `npm run build`
   - Build output directory: `dist`
   - Root directory: leave blank if the project files are at the repository root.
6. Click **Save and Deploy**.
7. Wait for the build to finish, then open the `*.pages.dev` URL Cloudflare provides.

If deployment fails, open the failed deployment's build log and copy the first meaningful error so it can be diagnosed.

## Suggested next development steps

1. Add authentication and role-based permissions for teachers/admins.
2. Add a managed database (for example, Cloudflare D1) and server-side API for shared records.
3. Add import/restore, printable lesson plans, school-specific CBC templates, and richer reporting.
4. Add backups, access controls, and a privacy review before using real learner records.


## Published resource files

The Grade 2 Creative Activities lesson notes are stored in `public/resources/` and linked from the **Free downloads** page. When deployed, the download links are served from `/resources/`. Add future resources to this folder and add a matching card/link in `src/App.jsx`.
